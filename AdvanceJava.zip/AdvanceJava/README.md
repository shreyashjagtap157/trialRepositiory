# AdvanceJava
AdvanceJava Mini projects (Use of : Servlet , Spring boot MVC , JSP and JSTL)
