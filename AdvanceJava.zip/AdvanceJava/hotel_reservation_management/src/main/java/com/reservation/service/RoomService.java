package com.reservation.service;

public interface RoomService {

	
	
}
