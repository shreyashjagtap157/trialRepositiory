package com.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelReservationManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelReservationManagementApplication.class, args);
	}

}
