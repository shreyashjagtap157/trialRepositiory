package com.reservation.entites;

public enum Availability {
YES,NO
}
