package com.app.custom_mapper;

public class Room_RoomDTO {
 
}
