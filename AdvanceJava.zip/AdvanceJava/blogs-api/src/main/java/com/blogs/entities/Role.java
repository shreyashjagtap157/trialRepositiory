package com.blogs.entities;

public enum Role {
	ADMIN, BLOGGER,COMMENTER
}
